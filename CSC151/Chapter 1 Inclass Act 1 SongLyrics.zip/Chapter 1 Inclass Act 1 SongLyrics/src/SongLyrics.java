
public class SongLyrics {
//The song is called Copernicus Crater by Duster
	public static void main(String[] args) {
		System.out.println("Shy of the shadows");
		System.out.println("Like you've been here before");
		System.out.println("Can't find a place in this world");
		System.out.println("You don't belong, moon child");

	}

}
