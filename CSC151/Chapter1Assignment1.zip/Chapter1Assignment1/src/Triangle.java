//Preston Evans, 1/11/24, This program will display a pattern that looks like a triangle.
public class Triangle {
	public static void main(String[] args) {
		System.out.println("      T");
		System.out.println("     TTT");
		System.out.println("    TTTTT");
		System.out.println("   TTTTTTT");
		System.out.println("  TTTTTTTTT");
		System.out.println(" TTTTTTTTTTT");
		System.out.println("TTTTTTTTTTTTT");
	}

}
