public class MovieQuote {
	//Preston Evans, 1/11/2024, This program displays a movie quote, the movie title, the year it came out, and the character that said it.
	public static void main(String[] args) {
		System.out.println("Movie: Pulp Fiction");
		System.out.println("Year: 1994");
		System.out.println("Character: Jules Winnfield");
		System.out.println("Quote: 'Say what again. Say what again. I dare you, I double dare you.' ");

	}

}
